<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class HomeController extends Controller
{
    //
    public function index(){
         include_once(app_path().'/includes/vid.php');
         include_once(app_path().'/includes/log.php');
          include_once(app_path().'/includes/browserdetection.php');
          include_once(app_path().'/includes/devicedetection.php');
         
    return view('home');
}
// public function getData($vid)
// {
//             $ret = DB::select('select * from tblform)
//                                       ->where('PropertyID',$vid)->get();   
//              $resultArray = $ret->toArray();
         
//           return view('home',compact('$resultArray'));
// }
}
