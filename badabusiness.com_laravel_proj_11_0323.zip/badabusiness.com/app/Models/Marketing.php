<?php

namespace App\Models;
use DB;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Marketing extends Model
{
    use HasFactory;
    protected $table="marketing";
    protected $fillable=['name','prize','img','description','category_id'];
    
    }
    
    // <a class="default-btn"  type="submit" href="{{url('/stock_market/'.$p->img.'/'.$p->name.'/'.$p->description.'/'.$p->prize)}}">Know More</a>