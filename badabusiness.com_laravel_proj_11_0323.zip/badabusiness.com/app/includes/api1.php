<?php 
// session_start();
// error_reporting(0);
// $url="https://www.badabusiness-trainings.com/bbmylogin/modules/Webforms/capture.php";
// $enu = base64_encode($url);
?>
<?php
//  echo "hello ";
//  $req_data = $_GET;
$request = $_GET;//$_REQUEST;
//  print_r($request);

$fp = fopen('log_badabussiness.txt', "a+");
fwrite($fp, "---------------111111----------------- \r\n");
fwrite($fp, json_encode($request));

 
//  echo $request;

function read($request_data){
    $fp = fopen('log_badabussiness.txt', "a+");
    $api_data = json_encode($request_data);
    // print_r("READ".$api_data);exit;
                
                $curl_connection =curl_init('https://www.badabusiness-trainings.com/bbmylogin/modules/Webforms/capture.php');
                curl_setopt($curl_connection, CURLOPT_CONNECTTIMEOUT, 30);
                curl_setopt($curl_connection, CURLOPT_USERAGENT,"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)");
                curl_setopt($curl_connection, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl_connection, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($curl_connection, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($curl_connection, CURLOPT_POSTFIELDS, $api_data);
                $result = curl_exec($curl_connection);
                print_r("result ".$result);exit;
                $err = curl_error($curl_connection);
                //print_r(curl_getinfo($curl_connection));
                echo curl_errno($curl_connection) . '-' . curl_error($curl_connection);
                curl_close($curl_connection); 
                // echo "<script>alert('$err');</script>";

                date_default_timezone_set('Asia/Kolkata'); 
            
                // fwrite($fp, "---------------222222----------------- \r\n");
                // fwrite($fp, $input);
                // $logfile= "../mylog.txt";
                //$IP = $_SERVER['REMOTE_ADDR'];
                 $logdetails= date("F j, Y, g:i a") . ': ' . 'Visitor ip='.$_SERVER['REMOTE_ADDR'] .'Email='.$request_data['email'] .'Mobile='. $request_data['mobile'].'ISD='.$request_data['cf_907'].'lastname='.$request_data['lastname'].'Result='.$result.'<br>' ;
                //   $logdetails= date("F j, Y, g:i a") . ': ' . 'Visitor ip='.$_SERVER['REMOTE_ADDR'] . 'project_id='.$request['cf_984']  .'project_name='.$request['cf_854']  .'Email='.$request['email'] .'Mobile='. $request['mobile'].'ISD='.$request['cf_888'].'lastname='.$request['lastname'] .'Result='.$result."<br>" ;

                 fwrite($fp, "---------------333333----------------- \r\n");
                fwrite($fp, json_encode($logdetails));
//$logdetails = 'Result :'.  $result;
                // open the file for reading and writing
                // $fp = fopen($logfile, "a+");

                // write out new log entry to the beginning of the file
                // fwrite($fp, $logdetails, strlen($logdetails));
                // file_put_contents('../mylog.txt',"\r\n",FILE_APPEND);
                // fclose($fp);
                // console.log("success");
                fclose($fp);
                return"success";
}

read($request);
fclose($fp);
?>