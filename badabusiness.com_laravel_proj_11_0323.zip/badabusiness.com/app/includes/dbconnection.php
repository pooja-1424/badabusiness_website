<?php
$con=mysqli_connect("localhost", "horizonfp_badabusiness", ")[N*_%_ZeYm0", "horizonfp_badabusiness");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
