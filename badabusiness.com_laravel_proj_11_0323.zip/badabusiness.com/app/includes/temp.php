<form id="__vtigerWebForm" name="Badabusiness Leads"
    action="https://www.badabusiness-trainings.com/bbmylogin/modules/Webforms/capture.php" method="post"
    accept-charset="utf-8" enctype="multipart/form-data"><input type="hidden" name="__vtrftk"
        value="sid:17f4c4f91601dca6e4327ea5e60ba998ad207ac5,1677321061"><input type="hidden" name="publicid"
        value="76a79ea12be03378c8ba3c7a92b4389f"><input type="hidden" name="urlencodeenable" value="1"><input
        type="hidden" name="name" value="Badabusiness Leads">
    <table>
        <tbody>
            <tr>
                <td><label>Last Name*</label></td>
                <td><input type="text" name="lastname" data-label="" value="" required=""></td>
            </tr>
            <tr>
                <td><label>Mobile Phone*</label></td>
                <td><input type="text" name="mobile" data-label="" value="" required=""></td>
            </tr>
            <tr>
                <td><label>Primary Email</label></td>
                <td><input type="email" name="email" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Lead Status*</label></td>
                <td><select name="cf_881" data-label="label:Lead+Status" required="">
                        <option value="">Select Value</option>
                        <option value="Cold Lead">Cold Lead</option>
                        <option value="Warm Lead" selected="">Warm Lead</option>
                        <option value="Hot Lead">Hot Lead</option>
                    </select></td>
            </tr>
            <tr>
                <td><label>Tracking Status*</label></td>
                <td><select name="cf_885" data-label="label:Tracking+Status" required="">
                        <option value="">Select Value</option>
                        <option value="Already Purchase">Already Purchase</option>
                        <option value="Fake">Fake</option>
                        <option value="Duplicate">Duplicate</option>
                        <option value="CP/IBC">CP/IBC</option>
                        <option value="Not Interested">Not Interested</option>
                        <option value="Hot Lead">Hot Lead</option>
                        <option value="VDNB">VDNB</option>
                        <option value="Fresh">Fresh</option>
                        <option value="Follow Up">Follow Up</option>
                        <option value="Call Back For Discussion By Seniar">Call Back For Discussion By Seniar</option>
                        <option value="Plan For Future">Plan For Future</option>
                        <option value="-" selected="">-</option>
                    </select></td>
            </tr>
            <tr>
                <td><label>Tracking Sub Status*</label></td>
                <td><select name="cf_887" data-label="label:Tracking+Sub+Status" required="">
                        <option value="">Select Value</option>
                        <option value="Active">Active</option>
                        <option value="Follow Up">Follow Up</option>
                        <option value="Qualified">Qualified</option>
                        <option value="Purchased">Purchased</option>
                        <option value="In Discussion">In Discussion</option>
                        <option value="Revisit Arranged">Revisit Arranged</option>
                        <option value="Not Interested">Not Interested</option>
                        <option value="Lost Due To Clash">Lost Due To Clash</option>
                        <option value="Ringing">Ringing</option>
                        <option value="Switch Off">Switch Off</option>
                        <option value="-" selected="">-</option>
                        <option value="Sales Qualified Lead">Sales Qualified Lead</option>
                    </select></td>
            </tr>
            <tr>
                <td><label>Time_Zone</label></td>
                <td><input type="text" name="cf_891" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Country</label></td>
                <td><input type="text" name="cf_893" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>State</label></td>
                <td><input type="text" name="cf_873" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Latitude</label></td>
                <td><input type="text" name="cf_897" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Longitude</label></td>
                <td><input type="text" name="cf_899" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>City</label></td>
                <td><input type="text" name="cf_875" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Visitor IP</label></td>
                <td><input type="text" name="cf_895" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Team Leader*</label></td>
                <td><select name="cf_921" data-label="label:Team+Leader" required="">
                        <option value="">Select Value</option>
                        <option value="Sunny Rajput" selected="">Sunny Rajput</option>
                    </select></td>
            </tr>
            <tr>
                <td><label>Country Code</label></td>
                <td><select name="cf_907" data-label="label:Country+Code">
                        <option value="">Select Value</option>
                        <option value="Indonesia +62">Indonesia +62</option>
                        <option value="44">44</option>
                        <option value="52">52</option>
                        <option value="968">968</option>
                        <option value="Belarus +375">Belarus +375</option>
                        <option value="65">65</option>
                        <option value="p:959">p:959</option>
                        <option value="p:992">p:992</option>
                        <option value="p:797">p:797</option>
                        <option value="p:916">p:916</option>
                        <option value="Nigeria +234">Nigeria +234</option>
                        <option value="973">973</option>
                        <option value="p:977">p:977</option>
                        <option value="p:989">p:989</option>
                        <option value="p:+94">p:+94</option>
                        <option value="p:887">p:887</option>
                        <option value="p:917">p:917</option>
                        <option value="p:+919">p:+919</option>
                        <option value="p:+910">p:+910</option>
                        <option value="p:957">p:957</option>
                        <option value="p:900">p:900</option>
                        <option value="p:771">p:771</option>
                        <option value="p:866">p:866</option>
                        <option value="p:+97">p:+97</option>
                        <option value="p:-48">p:-48</option>
                        <option value="p:000">p:000</option>
                        <option value="p+1">p+1</option>
                        <option value="p:+23">p:+23</option>
                        <option value="(+91)">(+91)</option>
                        <option value="p:965">p:965</option>
                        <option value="p:750">p:750</option>
                        <option value="p:743">p:743</option>
                        <option value="p:913">p:913</option>
                        <option value="p:720">p:720</option>
                        <option value="p:986">p:986</option>
                        <option value="Germany +49">Germany +49</option>
                        <option value="Zimbabwe +263">Zimbabwe +263</option>
                        <option value="9">9</option>
                        <option value="40">40</option>
                        <option value="New Zealand +64">New Zealand +64</option>
                        <option value="Afghanistan +93">Afghanistan +93</option>
                        <option value="p:865">p:865</option>
                        <option value="p:982">p:982</option>
                        <option value="Singapore +65">Singapore +65</option>
                        <option value="USA +1">USA +1</option>
                        <option value="971">971</option>
                        <option value="Saudi Arabia +966">Saudi Arabia +966</option>
                        <option value="p:+17">p:+17</option>
                        <option value="p:836">p:836</option>
                        <option value="p:+19">p:+19</option>
                        <option value="p:700">p:700</option>
                        <option value="p:773">p:773</option>
                        <option value="p:816">p:816</option>
                        <option value="p:932">p:932</option>
                        <option value="p:774">p:774</option>
                        <option value="p:+18">p:+18</option>
                        <option value="p:810">p:810</option>
                        <option value="India+91">India+91</option>
                        <option value="910">910</option>
                        <option value="p:+91">p:+91</option>
                        <option value="p:843">p:843</option>
                        <option value="1">1</option>
                        <option value="p:877">p:877</option>
                        <option value="p:88">p:88</option>
                        <option value="p:+99">p:+99</option>
                        <option value="p:937">p:937</option>
                        <option value="United Arab Emirates +971">United Arab Emirates +971</option>
                        <option value="p:983">p:983</option>
                        <option value="p:976">p:976</option>
                        <option value="p:997">p:997</option>
                        <option value="p:961">p:961</option>
                        <option value="p:+25">p:+25</option>
                        <option value="Canada +1">Canada +1</option>
                        <option value="p:+96">p:+96</option>
                        <option value="p:808">p:808</option>
                        <option value="p:882">p:882</option>
                        <option value="p:996">p:996</option>
                        <option value="p:981">p:981</option>
                        <option value="91">91</option>
                        <option value="592">592</option>
                        <option value="India +91">India +91</option>
                        <option value="p:+18779559001">p:+18779559001</option>
                        <option value="p:+917977313367">p:+917977313367</option>
                        <option value="p:+918459461587">p:+918459461587</option>
                        <option value="p:+919146041614">p:+919146041614</option>
                        <option value="p:+919699222237">p:+919699222237</option>
                        <option value="p:+918433555291">p:+918433555291</option>
                        <option value="p:+917405209080">p:+917405209080</option>
                        <option value="p:+919619228107">p:+919619228107</option>
                        <option value="p:+919699337299">p:+919699337299</option>
                        <option value="p:+919619153604">p:+919619153604</option>
                        <option value="p:+917045345367">p:+917045345367</option>
                        <option value="p:+919987652255">p:+919987652255</option>
                        <option value="p:+919326460501">p:+919326460501</option>
                        <option value="p:+919621428628">p:+919621428628</option>
                        <option value="p:+917718040548">p:+917718040548</option>
                        <option value="p:+919022742593">p:+919022742593</option>
                        <option value="p:+919819222908">p:+919819222908</option>
                        <option value="p:+919819162642">p:+919819162642</option>
                        <option value="p:+919137000751">p:+919137000751</option>
                        <option value="p:+919995256792">p:+919995256792</option>
                    </select></td>
            </tr>
            <tr>
                <td><label>Backend Source</label></td>
                <td><select name="cf_905" data-label="label:Backend+Source">
                        <option value="">Select Value</option>
                        <option value="FB">FB</option>
                        <option value="SEO">SEO</option>
                        <option value="Chat">Chat</option>
                        <option value="Google Search Network">Google Search Network</option>
                        <option value="Google SearchPatner">Google SearchPatner</option>
                        <option value="Google Display Network">Google Display Network</option>
                        <option value="WEBFORM">WEBFORM</option>
                        <option value="lg">lg</option>
                        <option value="IMPORT">IMPORT</option>
                        <option value="CRM">CRM</option>
                        <option value="YouTube">YouTube</option>
                        <option value="ppc">ppc</option>
                        <option value="WORKFLOW">WORKFLOW</option>
                        <option value="housingpushall">housingpushall</option>
                        <option value="ig">ig</option>
                        <option value="Web Call">Web Call</option>
                    </select></td>
            </tr>
            <tr>
                <td><label>Lead Source</label></td>
                <td><select name="leadsource" data-label="leadsource">
                        <option value="">Select Value</option>
                        <option value="Cold Call">Cold Call</option>
                        <option value="Facebook">Facebook</option>
                        <option value="ig">ig</option>
                        <option value="Web Call">Web Call</option>
                        <option value="Existing Customer">Existing Customer</option>
                        <option value="Self Generated">Self Generated</option>
                        <option value="Employee">Employee</option>
                        <option value="Partner">Partner</option>
                        <option value="Public Relations">Public Relations</option>
                        <option value="Direct Mail">Direct Mail</option>
                        <option value="Conference">Conference</option>
                        <option value="Trade Show">Trade Show</option>
                        <option value="Website">Website</option>
                        <option value="Word of mouth">Word of mouth</option>
                        <option value="Other">Other</option>
                    </select></td>
            </tr>
            <tr>
                <td><label>Ad Source</label></td>
                <td><input type="text" name="cf_967" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Ad source2</label></td>
                <td><input type="text" name="cf_977" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Product Name</label></td>
                <td><select name="cf_997" data-label="label:Product+Name">
                        <option value="">Select Value</option>
                        <option value="BCP">BCP</option>
                        <option value="LTM">LTM</option>
                        <option value="LFP">LFP</option>
                        <option value="IBC">IBC</option>
                        <option value="Bounce Back Mumbai">Bounce Back Mumbai</option>
                        <option value="Bounce Back">Bounce Back</option>
                        <option value="LFP PLUS">LFP PLUS</option>
                    </select></td>
            </tr>
            <tr>
                <td><label>URL</label></td>
                <td><input type="text" name="cf_903" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Description</label></td>
                <td><textarea name="description"></textarea></td>
            </tr>
            <tr>
                <td><label>Device Type</label></td>
                <td><input type="text" name="cf_935" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Match Type</label></td>
                <td><input type="text" name="cf_937" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Target</label></td>
                <td><input type="text" name="cf_939" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Placement</label></td>
                <td><input type="text" name="cf_971" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Loc Physical MS</label></td>
                <td><input type="text" name="cf_945" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Campaign ID</label></td>
                <td><input type="text" name="cf_925" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Creative</label></td>
                <td><input type="text" name="cf_949" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Network</label></td>
                <td><input type="text" name="cf_961" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Ad Position</label></td>
                <td><input type="text" name="cf_965" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Keyword</label></td>
                <td><input type="text" name="cf_1005" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Campaign Type</label></td>
                <td><input type="text" name="cf_1007" data-label="" value=""></td>
            </tr>
            <tr>
                <td><label>Sub-Product Name</label></td>
                <td><select name="cf_1009" data-label="label:Sub-Product+Name">
                        <option value="">Select Value</option>
                        <option value="PSC-Stock Market">PSC-Stock Market</option>
                    </select></td>
            </tr>
        </tbody>
    </table><input type="submit" value="Submit">
</form>
<script type="text/javascript">
window.onload = function() {
    var N = navigator.appName,
        ua = navigator.userAgent,
        tem;
    var M = ua.match(/(opera|chrome|safari|firefox|msie)\/?\s*(\.?\d+(\.\d+)*)/i);
    if (M && (tem = ua.match(/version\/([\.\d]+)/i)) != null) M[2] = tem[1];
    M = M ? [M[1], M[2]] : [N, navigator.appVersion, "-?"];
    var browserName = M[0];
    var form = document.getElementById("__vtigerWebForm"),
        inputs = form.elements;
    form.onsubmit = function() {
        var required = [],
            att, val;
        for (var i = 0; i < inputs.length; i++) {
            att = inputs[i].getAttribute("required");
            val = inputs[i].value;
            type = inputs[i].type;
            if (type == "email") {
                if (val != "") {
                    var elemLabel = inputs[i].getAttribute("label");
                    var emailFilter =
                        /^[_/a-zA-Z0-9]+([!"#$%&()*+,./:;<=>?\^_`{|}~-]?[a-zA-Z0-9/_/-])*@[a-zA-Z0-9]+([\_\-\.]?[a-zA-Z0-9]+)*\.([\-\_]?[a-zA-Z0-9])+(\.?[a-zA-Z0-9]+)?$/;
                    var illegalChars = /[\(\)\<\>\,\;\:\"\[\]]/;
                    if (!emailFilter.test(val)) {
                        alert("For " + elemLabel + " field please enter valid email address");
                        return false;
                    } else if (val.match(illegalChars)) {
                        alert(elemLabel + " field contains illegal characters");
                        return false;
                    }
                }
            }
            if (att != null) {
                if (val.replace(/^\s+|\s+$/g, "") == "") {
                    required.push(inputs[i].getAttribute("label"));
                }
            }
        }
        if (required.length > 0) {
            alert("The following fields are required: " + required.join());
            return false;
        }
        var numberTypeInputs = document.querySelectorAll("input[type=number]");
        for (var i = 0; i < numberTypeInputs.length; i++) {
            val = numberTypeInputs[i].value;
            var elemLabel = numberTypeInputs[i].getAttribute("label");
            var elemDataType = numberTypeInputs[i].getAttribute("datatype");
            if (val != "") {
                if (elemDataType == "double") {
                    var numRegex = /^[+-]?\d+(\.\d+)?$/;
                } else {
                    var numRegex = /^[+-]?\d+$/;
                }
                if (!numRegex.test(val)) {
                    alert("For " + elemLabel + " field please enter valid number");
                    return false;
                }
            }
        }
        var dateTypeInputs = document.querySelectorAll("input[type=date]");
        for (var i = 0; i < dateTypeInputs.length; i++) {
            dateVal = dateTypeInputs[i].value;
            var elemLabel = dateTypeInputs[i].getAttribute("label");
            if (dateVal != "") {
                var dateRegex = /^[1-9][0-9]{3}-(0[1-9]|1[0-2]|[1-9]{1})-(0[1-9]|[1-2][0-9]|3[0-1]|[1-9]{1})$/;
                if (!dateRegex.test(dateVal)) {
                    alert("For " + elemLabel + " field please enter valid date in required format");
                    return false;
                }
            }
        }
        var inputElems = document.getElementsByTagName("input");
        var totalFileSize = 0;
        for (var i = 0; i < inputElems.length; i++) {
            if (inputElems[i].type.toLowerCase() === "file") {
                var file = inputElems[i].files[0];
                if (typeof file !== "undefined") {
                    var totalFileSize = totalFileSize + file.size;
                }
            }
        }
        if (totalFileSize > 52428800) {
            alert("Maximum allowed file size including all files is 50MB.");
            return false;
        }
    };
}
</script>