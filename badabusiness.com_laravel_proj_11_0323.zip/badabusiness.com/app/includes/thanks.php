
<html>
<title>Thank You</title>

<head>

 <!-- Global site tag (gtag.js) -->
<!--****** Google related Codes2 ******-->

<!-- Global site tag (gtag.js) 3 - Google Analytics -->


<!-- Event Snippet -->
<!-- Event snippet for Raunak Grand Centre conversion page  4-->



</head>


<body>
<!--******  Clickcease.com tracking 11******-->


<section style="top:50px;">
  <span class="section-link">
  </span>
  <span class="head text-capitalize"></span>
  <div class="row mb-3">
    <img src="img/thankyou.jpg" class="img-responsive" style="width: -webkit-fill-available; background-image:no-repeat; " alt="thanks" >
  </div>
  <script>
    setTimeout(function() {
      window.location.href ="{{ url('/home') }}"
    }, 10000);
  </script>
</section>
</body>
</html>