@extends('components/head')
<link  href="{{asset('public/css/a74f6e1f5cb94126.css')}}" rel="stylesheet"> 
<link href="{{url('public/css/bootstrap.css')}}" rel="stylesheet">
@include('selectjs')
<?php
session_start();
error_reporting(0);
$url="https://www.badabusiness-trainings.com/bbmylogin/modules/Webforms/capture.php";
$enu = base64_encode($url);
?>
<section>
    <img src="https://99soft.in/badabusiness.com/public/img/website_badabusiness_image.jpg" class="aa" style="width:1450px;">
            <div class="container ">
                <!-- <a href="tel:+919167729245" class="con5">
                <span><img src="img/call_icon.png" alt="call" style="max-width:20%;">9167729245</span>
                </a> -->
            </div>
        </section>
     <section class="bg-f9f9f9 about-area pt-70 pb-70" style="background-color:#eee;margin-top:24px;margin-bottom:-92px">
       <div class="main-banner-area">
        <div class="container">
          <div class="main-banner-content">          
            <form>
              <div class="row m-0 align-items-center">
                <div class="col-lg-5 col-md-6 p-0">
                  <div class="form-group category-select">                    
                    <select class="banner-form-select" id="s1">
                      <option value="{{$cList->category_id}}">Select Category </option>
                  @foreach(App\Models\Category::all() as $cList)
                    <option class="option" value="{{$cList->category_id}}" >{{$cList->name}}</option>
                  @endforeach
                    </select>
                  </div>
                </div>                
                {{-- <div class="col-lg-3 col-md-6 p-0">
                  <div class="form-group category-select">                   
                    <select class="banner-form-select">
                      <option>PSC </option>
                      <option>PSC</option>                    
                    </select>
                  </div>
                </div> --}}
                <div class="col-lg-5 col-md-12 p-0">
                  <div class="form-group">                  
                    <input type="search" id="tags" name="search" class="form-control" placeholder="What are you looking for?" required > </select>
                    <i class="fa fa-search" aria-hidden="true"></i>
                 </div>
                </div>
                <div class="col-lg-2 col-md-12 p-0">
                  <div class="submit-btn">
                    <button type="submit">Search Now</button>
                  </div>
                </div>
              </div>
            </form>           
          </div>
        </div>
      </div>
    </section>  

<section class="product-details-cc">
<div class="container" id="courses"  >
<div class="row">   
  <div class="col-lg-12 col-md-12">  
  @foreach($data->take(8) as $p)
    <div class="single-listings-item11">
      <div class="row m-0">
        <div class="col-lg-5 col-md-4 p-0">         
          <div class="post-image">
            <a class="d-block" href="https://horizonfp.co.in/99soft.in/badabusiness.com/PSC/ecommerce.php" style="height:250px;">
              <img src="{{ url('') }}/public/img/{{$p->img}}" class="main-image1" alt="image">
            </a>
          </div>
        </div>       
        <div class="col-lg-5 col-md-12 ">
                  <div class="products-details-desc">
                 <div class="products-content" style="margin-top:40px;">                    
                      <h2 style="font-size:28px;">
                        <a>{{$p->name}}</a>
                      </h2>
                         <p><b>KEY  COURSE  OUTCOMES</b></p>
                         <ul class="ul-item">  
                            @php $count = 0; @endphp                                                     
                            @foreach(str_replace(['""'],[''], explode(".",$p->description)) as $key => $val)
                            @php if($count == 7) break; @endphp
                              <li> {{ $val }} </li>
                              @php $count++; @endphp
                            @endforeach            
                        </ul>
                     </div> 
                </div>
            </div>
          <div class="col-lg-2 col-md-8 p-0">
          <div class="listings-content"><br><br>
          <br><br>
          <div class="price">          
              <span class="new-price">{{$p->price}}</span>             
          </div>
          <div class="manage-your-business-content">
         <!--<a class="default-btn" type="submit" href="{{ url(details, ['name'=>$p->name]) }}">Know More</a>-->
           <a class="default-btn" type="submit"  href="{{ url("/details/$p->id"."/". Str::slug($p->name)) }}">Know More</a>
        </div>                        
       </div>
     </div>
   </div>
</div>   
@endforeach     
</div>
</div> 
</div>
</div> 
</section>

@extends('components/footer')
