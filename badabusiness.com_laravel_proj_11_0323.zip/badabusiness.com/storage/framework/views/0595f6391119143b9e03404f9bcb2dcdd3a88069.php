
<link  href="<?php echo e(asset('public/css/a74f6e1f5cb94126.css')); ?>" rel="stylesheet"> 
<link href="<?php echo e(url('public/css/bootstrap.css')); ?>" rel="stylesheet">
<?php echo $__env->make('selectjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
session_start();
error_reporting(0);
$url="https://www.badabusiness-trainings.com/bbmylogin/modules/Webforms/capture.php";
$enu = base64_encode($url);
?>
<section>
    <img src="https://99soft.in/badabusiness_laravel.com/public/img/website_badabusiness_image.jpg" class="aa" style="width:1450px;">
            <div class="container ">
                <!-- <a href="tel:+919167729245" class="con5">
                <span><img src="img/call_icon.png" alt="call" style="max-width:20%;">9167729245</span>
                </a> -->
            </div>
        </section>
     <section class="bg-f9f9f9 about-area pt-70 pb-70" style="background-color:#eee;margin-top:24px;margin-bottom:-92px">
       <div class="main-banner-area">
        <div class="container">
          <div class="main-banner-content">          
            <form>
              <div class="row m-0 align-items-center">
                <div class="col-lg-5 col-md-6 p-0">
                  <div class="form-group category-select">                    
                    <select class="banner-form-select" id="s1">
                      <option value="<?php echo e($cList->category_id); ?>">Select Category </option>
                  <?php $__currentLoopData = App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option class="option" value="<?php echo e($cList->category_id); ?>" ><?php echo e($cList->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>                
                
                <div class="col-lg-5 col-md-12 p-0">
                  <div class="form-group">                  
                    <input type="search" id="tags" name="search" class="form-control" placeholder="What are you looking for?" required > </select>
                    <i class="fa fa-search" aria-hidden="true"></i>
                 </div>
                </div>
                <div class="col-lg-2 col-md-12 p-0">
                  <div class="submit-btn">
                    <button type="submit">Search Now</button>
                  </div>
                </div>
              </div>
            </form>           
          </div>
        </div>
      </div>
    </section>  

<section class="product-details-cc">
<div class="container" id="courses"  >
<div class="row">   
  <div class="col-lg-12 col-md-12">  
  <?php $__currentLoopData = $data->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="single-listings-item11">
      <div class="row m-0">
        <div class="col-lg-5 col-md-4 p-0">         
          <div class="post-image">
            <a class="d-block" href="https://horizonfp.co.in/99soft.in/badabusiness.com/PSC/ecommerce.php" style="height:250px;">
              <img src="<?php echo e(url('')); ?>/public/img/<?php echo e($p->img); ?>" class="main-image1" alt="image">
            </a>
          </div>
        </div>       
        <div class="col-lg-5 col-md-12 ">
                  <div class="products-details-desc">
                 <div class="products-content" style="margin-top:40px;">                    
                      <h2 style="font-size:28px;">
                        <a><?php echo e($p->name); ?></a>
                      </h2>
                         <p><b>KEY  COURSE  OUTCOMES</b></p>
                         <ul class="ul-item">  
                            <?php $count = 0; ?>                                                     
                            <?php $__currentLoopData = str_replace(['""'],[''], explode(".",$p->description)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($count == 7) break; ?>
                              <li> <?php echo e($val); ?> </li>
                              <?php $count++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                        </ul>
                     </div> 
                </div>
            </div>
          <div class="col-lg-2 col-md-8 p-0">
          <div class="listings-content"><br><br>
          <br><br>
          <div class="price">          
              <span class="new-price"><?php echo e($p->price); ?></span>             
          </div>
          <div class="manage-your-business-content">
         <!--<a class="default-btn" type="submit" href="<?php echo e(url(details, ['name'=>$p->name])); ?>">Know More</a>-->
           <a class="default-btn" type="submit"  href="<?php echo e(url("/details/$p->id"."/". Str::slug($p->name))); ?>">Know More</a>
        </div>                        
       </div>
     </div>
   </div>
</div>   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
</div>
</div> 
</div>
</div> 
</section>



<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/horizb9k/public_html/99soft.in/badabusiness_laravel.com/resources/views/psc.blade.php ENDPATH**/ ?>