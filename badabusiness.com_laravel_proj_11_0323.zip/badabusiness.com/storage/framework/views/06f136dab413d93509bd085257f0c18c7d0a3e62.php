<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
<script>
   
        $(document).ready(function(){    
      $("#s1").on('change', function(){
            var category = $(this).val();
            // alert(category);
             $.ajax({
              type: 'get',
              dataType: 'html',
              url: '<?php echo e(url('/courses')); ?>',
              data: {'category':category},
              success:function(data){
                // console.log(data);
                $("#courses").html(data);
             }
            });
        });
       
    });
</script>
      
<script>
  $(document).ready(function(){
     $('#showvideo').click(function(){
        $('#myModal').show();
     });
  });       
</script>




<?php /**PATH C:\xampp\htdocs\badabusiness\resources\views/selectjs.blade.php ENDPATH**/ ?>