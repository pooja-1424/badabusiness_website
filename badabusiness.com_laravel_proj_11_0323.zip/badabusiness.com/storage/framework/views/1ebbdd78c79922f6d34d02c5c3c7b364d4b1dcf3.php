
<link  href="<?php echo e(asset('css/a74f6e1f5cb94126.css')); ?>" rel="stylesheet"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" >
<link href="https://fonts.googleapis.com/css2?family=Work+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.css" rel="stylesheet">
<link href="../css/bootstrap.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
<?php
session_start();
error_reporting(0);
// include('includes/dbconnection.php');
// include('includes/vid.php');
// include('includes/log.php');
// include('includes/browserdetection.php');
// include('includes/devicedetection.php');
// include('includes/backend.php'); 

$url="https://www.badabusiness-trainings.com/bbmylogin/modules/Webforms/capture.php";
$enu = base64_encode($url);

?>


<section>
    <img src="../img/Bada_Business_creative_PSC_Banner_images1.jpg">
            <div class="container ">
                <!-- <a href="tel:+919167729245" class="con5">
                <span><img src="img/call_icon.png" alt="call" style="max-width:20%;">9167729245</span>
                </a> -->
            </div>
        </section>
    <section class="bg-f9f9f9 about-area pt-70 pb-70" style="background-color:#e9ecef;">
    <div class="container">
    <div class="main-banner-content"> 
        <h2>Problem Solving Courses (PSC)</h2>
        <div class="container">
  <div class="main-banner-content">
   
    
    <form>
      <div class="row m-0 align-items-center">
        <div class="col-lg-5 col-md-6 p-0">
          <div class="form-group category-select">
              <select class="banner-form-select" >
              <option>All Categories</option>
              <option>Marketing</option>
              <option>Social Media</option>
              <option value="clothing">Clothing</option>
              <option>Bank</option>
              <option>Fitness</option>
              <option>Bookstore</option>
              <option>Shopping</option>
              <option>Hotels</option>
              <option>Hospitals</option>
              <option>Culture</option>
              <option>Beauty</option>
              
            </select>
          </div>
        </div>
        <div class="col-lg-5 col-md-6 p-0">
          <div class="form-group category-select">
              <select class="banner-form-select">
              <option>PSC</option>
                         </select>
          </div>
        </div>
        <div class="col-lg-2 col-md-12 p-0">
          <div class="submit-btn">
            <button type="submit">Search Now</button>
          </div>
        </div>
      </div>
    </form>  
  </div>
</div>
</section>
<div class="card card-body listing_cardd">
                            <div class="media align-items-center align-items-lg-start text-center text-lg-left flex-column flex-lg-row">
                                <div class="mr-2 mb-3 mb-lg-0">
                                <a href="https://badabusiness.com/psc/details/low-cost-marketing-ideas" data-abc="true" class="csTitle">
                                                                            <img src="https://s3.ap-south-1.amazonaws.com/vivekbindra-app/bindraapp/9ea109e6949aecf939f3c1c7738d2738.jpeg" class="img-fluid" alt="" width="316" height="200">
                                                                    </a>
                                </div>
                                <div class="media-body">
                                    <div class="row">
                                        <div class="col-sm-6 col-12 bdr-rght center_body">
                                            <h5 class="media-title font-weight-semibold">
                                                <a href="https://badabusiness.com/psc/details/low-cost-marketing-ideas" data-abc="true" class="csTitle">Low Cost Marketing Ideas</a>
                                            </h5>
                                                                                            <div class="author">
                                                    <h6 style="color: #000 !important;font-weight: 500 !important;">Professor :
                                                        <span style="color: #000 !important;" class="d-inline list-inline list-inline-dotted mb-3 mb-lg-2" data-abc="true">Ms. Samriti Grover</span>
                                                    </h6>

                                                    <h6 style="color: #000 !important;font-weight: 500 !important;">Designation :
                                                        <span style="color: #000 !important;" class="d-inline list-inline list-inline-dotted mb-3 mb-lg-2" data-abc="true">VP - Group Content Head - Bada Business Pvt. Ltd.</span>
                                                    </h6>
                                                </div>
                                                <ul class="list-inline list-inline-dotted">
                                                    <li class="list-block-item"><b>Category : </b>Marketing</li>
                                                    <li class="list-block-item"><b>User Purchased Count : </b>43,100</li>
                                                </ul>
                                                
                                                                                                <div>
                                                    <h6 style="color: #000 !important;font-weight: 500 !important; display:inline;">Rating : </h6>
                                                                                                            <i class="fa fa-star"></i>
                                                                                                            <i class="fa fa-star"></i>
                                                                                                            <i class="fa fa-star"></i>
                                                                                                            <i class="fa fa-star"></i>
                                                                                                        <span class="text-muted">(145)</span>
                                                </div>
                                                                                                                                        <p class="mt-3 mb-2 text-muted">This course provides several powerful low-cost Guerilla marketing ideas to promote and grow your business. This course will help you to understand different typ...</p>
                                                                                    </div>
                                        <div class="col-sm-6 col-12 rght_body">
                                            <h4>Topics Covered</h4>
                                            <ul class="list-inline list-inline-dotted mt-2 text-muted prob">
                                                                                                            <li class="list-block-item">Viral Marketing </li>
                                                                                                                    <li class="list-block-item">Street Marketing</li>
                                                                                                                    <li class="list-block-item">Undercover Marketing </li>
                                                                                                                    <li class="list-block-item">Nano Influencer Marketing</li>
                                                                                                                    <li class="list-block-item">Film-Based Marketing</li>
                                                                                                                    <li class="list-block-item">Moment Marketing </li>
                                                                                                                    <li class="list-block-item">Introduction</li>
                                                                                                                    <li class="list-block-item">Summary</li>
                                                                                                    </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-3 mt-lg-0 ml-lg-3 text-center right_mrp">

                                
                                    <h3 class="mb-0 font-weight-semibold" style="color:#000 !important;">Rs. 12,500</h3>                                   
                                    
                                    <button type="button" class="btn mt-2 btn_psc btn_buy open-frm-modals" data-title="Low Cost Marketing Ideas" data-product_id="480"> Buy Now</button><br>
                                    <a href="https://badabusiness.com/psc/details/low-cost-marketing-ideas" class="btn mt-2 btn_psc btn_learn">Course Details</a>
                                </div>
                            </div>
                        </div> 

<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\badabusiness\resources\views/pscon.blade.php ENDPATH**/ ?>