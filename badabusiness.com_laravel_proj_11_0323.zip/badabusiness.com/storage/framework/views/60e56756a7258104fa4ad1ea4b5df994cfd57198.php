<section class="product-details-cc">
    <div class="container" id="courses"  >
    <div class="row">   
      <div class="col-lg-12 col-md-12">  
      <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="single-listings-item11">
          <div class="row m-0">
            <div class="col-lg-5 col-md-4 p-0">         
              <div class="post-image">
                <a class="d-block" href="https://horizonfp.co.in/99soft.in/badabusiness.com/PSC/ecommerce.php" style="height:250px;">
                  <img src="<?php echo e(url('')); ?>/../img/<?php echo e($p->img); ?>" class="main-image1" alt="image">
                </a>
              </div>
            </div>       
            <div class="col-lg-5 col-md-12 ">
                      <div class="products-details-desc">
                     <div class="products-content" style="margin-top:40px;">                    
                          <h2 style="font-size:28px;">
                            <a><?php echo e($p->name); ?></a>
                          </h2>
                             <p><b>KEY  COURSE  OUTCOMES</b></p>
                             <ul class="ul-item">  
                                <?php $count = 0; ?>                                                     
                                <?php $__currentLoopData = str_replace(['""'],[''], explode(".",$p->description)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($count == 7) break; ?>
                                  <li> <?php echo e($val); ?> </li>
                                  <?php $count++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                            </ul>
                         </div> 
                    </div>
                </div>
              <div class="col-lg-2 col-md-8 p-0">
              <div class="listings-content"><br><br>
              <br><br>
              <div class="price">          
                  <span class="new-price"><?php echo e($p->price); ?></span>             
              </div>
              <div class="manage-your-business-content">
              <a class="default-btn" id="<?php echo e($p->id); ?>" type="submit" href="<?php echo e(url('/product_details/'.$p->img.'/'.$p->name.'/'.$p->price.'/'.$p->description)); ?>">Know More</a>
               </div>                        
              </div>
            </div>
            </div>
        </div>   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
      </div>
      </div> 
    </div>
    </div> 
    </section><?php /**PATH /home/horizb9k/public_html/99soft.in/badabusiness_laravel.com/resources/views/courses.blade.php ENDPATH**/ ?>