
<link  href="<?php echo e(asset('css/a74f6e1f5cb94126.css')); ?>" rel="stylesheet"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" >
<link href="https://fonts.googleapis.com/css2?family=Work+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.css" rel="stylesheet">
<link href="{{url'../css/bootstrap.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
<?php
session_start();
error_reporting(0);
// include('includes/dbconnection.php');
// include('includes/vid.php');
// include('includes/log.php');
// include('includes/browserdetection.php');
// include('includes/devicedetection.php');
// include('includes/backend.php'); 

$url="https://www.badabusiness-trainings.com/bbmylogin/modules/Webforms/capture.php";
$enu = base64_encode($url);
?>
<section>
    <img src="/img/Bada_Business_creative_PSC_Banner_images1.jpg">
            <div class="container ">
                <!-- <a href="tel:+919167729245" class="con5">
                <span><img src="img/call_icon.png" alt="call" style="max-width:20%;">9167729245</span>
                </a> -->
            </div>
        </section>
  <section class="bg-f9f9f9 about-area pt-70 pb-70" style="background-color:#e9ecef;">
    <div class="container">
    <div class="main-banner-content"> 
        <h2>Problem Solving Courses (PSC)</h2>
        <div class="container">
  <div class="main-banner-content"> 
    <form>
      <div class="row m-0 align-items-center">
        <div class="col-lg-6 col-md-6 p-0">
          <div class="form-group category-select">
              <select class="banner-form-select" onChange=selectedCourses(value)>
              <option>All Categories</option>
              <option value="Marketing">Marketing</option>
              <option value="social media">Social Media</option>
              <option>Clothing</option>
              <option>Bank</option>
              <option>Fitness</option>
              <option>Bookstore</option>
              <option>Shopping</option>
              <option>Hotels</option>
              <option>Hospitals</option>
              <option>Culture</option>
              <option>Beauty</option>              
            </select>
          </div>
        </div>        
<div class="col-lg-6 col-md-6 p-0">
          <div class=" category-select">
          <input type="search" id="tags" class="form-control" placeholder="What are you looking for?" style="border:none;" > </select>
          <i class="fa fa-search" aria-hidden="true"></i>
        </div>        
      </div>
    </form>  
  </div>
</div>
</section>
<!-------------------------------Marketing-------------------------------->
<section>
<div class="container" id="courses"  >
<div class="row">   
  <div class="col-lg-12 col-md-12">  
      <div class="single-listings-item11">
      <div class="row m-0">
        <div class="col-lg-5 col-md-4 p-0">         
          <div class="post-image">
            <a class="d-block" href="https://horizonfp.co.in/99soft.in/badabusiness.com/PSC/ecommerce.php" style="height:250px;">
              <img src="<?php echo e($img); ?>" class="main-image1" alt="image">
            </a>
          </div>
        </div>       
        <div class="col-lg-5 col-md-12 ">
                  <div class="products-details-desc">
                 <div class="products-content" style="margin-top:40px;">                    
                      <h2 style="font-size:40px;">
                        <a><?php echo e($name); ?></a>
                      </h2>
                         <p><b>KEY  COURSE  OUTCOMES</b></p>
                         <ul>
                            <!-- <li><?php echo e($p->description); ?></li>                             -->
                            <?php $__currentLoopData = str_replace(['""'],[''], explode(".",$description)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li><?php echo e($val); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                        </ul>
                     </div> 
                </div>
            </div>
          <div class="col-lg-1 col-md-8 p-0">
          <div class="listings-content"><br><br>
          <br><br>
          <div class="price">          
              <span class="new-price"><?php echo e($prize); ?></span>
          </div>
          <div class="manage-your-business-content">
          <!-- <a class="default-btn"  type="submit" href="<?php echo e(url('/stock_market/'.$p->id,$p->name)); ?>">Know More</a> -->
           </div>                        
          </div>
        </div>
        </div>
    </div>
   </div> 
</div>
</div> 
</section>
<?php echo $__env->make('components/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\badabusiness\resources\views/stock_market.blade.php ENDPATH**/ ?>